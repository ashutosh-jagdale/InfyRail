package infyrail.Route.Service;

import infyrail.Route.Dto.RouteMsDto;
import infyrail.Route.Dto.fullRouteDto;

public interface RouteMsService {
public int createRouteMs(RouteMsDto dto);
public fullRouteDto getRouteByID(int id);
public int getIdBySourceAndDestination(String source,String destination);
public String updateSourceandDestination(int id,String source,String destination);
}
