package infyrail.Route.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import infyrail.Route.Dto.fullRouteDto;
import infyrail.Route.Dto.RouteMsDto;
import infyrail.Route.Dto.fullRouteDto;
import infyrail.Route.Repo.RouteMsRepo;
import infyrail.Route.entity.Route;
@Service
@PropertySource("classpath:ValidationMessages.properties")
public class RouteMsServiceImpl implements RouteMsService {
	@Autowired
	RouteMsRepo routeMsRepo;
	@Override
	public int createRouteMs(RouteMsDto dto) {
		Route route=RouteMsDto.prepareEntity(dto);
		routeMsRepo.save(route);
		return route.getId();
	}
	@Override
	public  fullRouteDto getRouteByID(int id) {
		Route route=routeMsRepo.getById(id);
		 fullRouteDto dto=new fullRouteDto();
		 dto.setId(route.getId());
		 dto.setDestination(route.getDestination());
		 dto.setSource(route.getSource());
		 return dto;
	}
	public String updateSourceandDestination(int id, String source,String destination) {
		Route route=routeMsRepo.getById(id);
		route.setSource(source);
		route.setDestination(destination);
		routeMsRepo.save(route);
		return "updated succesfully";
	}
	@Override
	public int getIdBySourceAndDestination(String source, String destination) {
		Route route=routeMsRepo.findBySourceAndDestination(source, destination);
		return route.getId();
	}
}
