package infyrail.Route.Repo;
import infyrail.Route.entity.Route;
import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface RouteMsRepo extends JpaRepository<Route,Integer>{
	Route findBySourceAndDestination(String source,String destination);

}
