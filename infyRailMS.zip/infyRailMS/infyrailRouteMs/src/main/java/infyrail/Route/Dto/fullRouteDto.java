package infyrail.Route.Dto;

import java.util.List;

public class fullRouteDto {
	private int Id;
	private String Source;
	private String Destination;
	List<TrainMsDto> trainlist;
	public fullRouteDto() {
		super();
	}
	public fullRouteDto(int id, String source, String destination, List<TrainMsDto> trainlist) {
		super();
		Id = id;
		Source = source;
		Destination = destination;
		this.trainlist = trainlist;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public List<TrainMsDto> getTrainlist() {
		return trainlist;
	}
	public void setTrainlist(List<TrainMsDto> trainlist) {
		this.trainlist = trainlist;
	}
	@Override
	public String toString() {
		return "fullRouteDto [Id=" + Id + ", Source=" + Source + ", Destination=" + Destination + ", trainlist="
				+ trainlist + "]";
	}
	
}
