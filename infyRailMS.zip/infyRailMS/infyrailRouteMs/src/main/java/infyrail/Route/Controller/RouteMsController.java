package infyrail.Route.Controller;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import infyrail.Route.Dto.RouteMsDto;
import infyrail.Route.Dto.TrainMsDto;
import infyrail.Route.Dto.fullRouteDto;
import infyrail.Route.Service.RouteMsServiceImpl;
import infyrail.Route.exceptions.ErrorMessage;

@RestController
@RequestMapping("routes")
@CrossOrigin
@Validated
public class RouteMsController {
	@Value("${train.uri}")
	String trainUri;
	@Autowired
	RestTemplate template;
	@Autowired
	RouteMsServiceImpl serImpl;
	@PostMapping
	public ResponseEntity addRoute(@Valid @RequestBody RouteMsDto dto,Errors errors)
	{
		String response = "";
		if (errors.hasErrors()) 
		{			
			response  = errors.getAllErrors().stream().
					map(x->x.getDefaultMessage()).
						collect(Collectors.joining(","));
			ErrorMessage error = new ErrorMessage();
		    error.setErrorCode(HttpStatus.NOT_ACCEPTABLE.value());
		    error.setMessage(response);
		    return ResponseEntity.ok(error);
		}
	else
	{
		int id=serImpl.createRouteMs(dto);
		return  ResponseEntity.ok(id);
	}
	}
	@PutMapping(path="{routeId}")
	public String updateSourceandDestination(@PathVariable("routeId") int id,@MatrixVariable("source") @Pattern(regexp="[a-zA-z]{1,}",message= "{route.source.must}")String source,@MatrixVariable String destination)
	{
		return serImpl.updateSourceandDestination(id,source,destination);
	}
	@GetMapping(path="{routeId}")
	public fullRouteDto getroutebyId(@PathVariable int routeId)
	{
		fullRouteDto dto=serImpl.getRouteByID(routeId);
		List<TrainMsDto> trainlist=new RestTemplate().getForObject(trainUri+routeId,List.class);
		dto.setTrainlist(trainlist);
		return dto;
	}
	@HystrixCommand(fallbackMethod="getTrainsBySourceAndDestinationFallback")
	@GetMapping(path="trains")
	public List<TrainMsDto> getTrainsBySourceAndDestination(@RequestParam("source") String source,@RequestParam("destination") String destination)
	{
		int id=serImpl.getIdBySourceAndDestination(source, destination);
		List<TrainMsDto> trainlist=template.getForObject("http://INFYRAILTRAINMS/trains/"+id,List.class);
		
		return trainlist;
	}
	@DeleteMapping(path="{routeId}/{trainId}")
	public void deleteTrain(@PathVariable("routeId") int rid,@PathVariable("trainId") int tid) 
	{
		template.delete("http://INFYRAILTRAINMS/trains/"+rid+"/"+tid);
	}
	@PutMapping(path="{routeId}/trains")
	public void updateTrainDetailsByRouteId(@PathVariable("routeId") int id,@RequestBody List<TrainMsDto> Traindetails)
	{
		new RestTemplate().put(trainUri+"/"+id+"/trains", Traindetails);
	}
	public List<TrainMsDto> getTrainsBySourceAndDestinationFallback(String source,String Destination)
	{
		List<TrainMsDto> l=new ArrayList<>();
		TrainMsDto dto=new TrainMsDto();
		l.add(dto);
		return l ;
	}
}
