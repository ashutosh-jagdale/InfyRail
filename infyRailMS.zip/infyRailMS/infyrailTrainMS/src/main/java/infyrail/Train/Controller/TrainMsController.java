package infyrail.Train.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import infyrail.Train.dto.TrainMsDto;
import infyrail.Train.dto.TrainUpdate;
import infyrail.Train.service.TrainMsServiceImpl;

@RestController
@RequestMapping("trains")
public class TrainMsController {
@Autowired
TrainMsServiceImpl trainser;
@PostMapping
public int createTrain(@RequestBody TrainMsDto dto)
{
	int id=trainser.createTrain(dto);
	return id;
}
@PutMapping(path="{trainId}")
public String updateFare(@PathVariable("trainId") int id,@RequestBody TrainUpdate fare)
{
	return trainser.updateFare(id,fare);

}
@GetMapping("{routeId}")
public List<TrainMsDto> getTrainByRouteId(@PathVariable("routeId") int routeId)
{
	return trainser.getTrainByRouteId(routeId);
}
@DeleteMapping(path="{routeId}/{trainId}")
public String deleteTrain(@PathVariable("routeId") int rid,@PathVariable("trainId") int tid) 
{
	return trainser.deleteTrain(rid, tid);
}
@PutMapping(path="{routeId}/trains")
public void updateTrainDetailsByRouteId(@PathVariable("routeId") int id,@RequestBody List<TrainMsDto> Traindetails)
{
	trainser.updateTrainDetailsByRouteId(id,Traindetails );
}
}
