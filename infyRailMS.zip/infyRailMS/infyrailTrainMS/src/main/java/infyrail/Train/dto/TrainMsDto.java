package infyrail.Train.dto;

import infyrail.Train.entity.Train;

public class TrainMsDto {
	private int id;
	private String trainName;
	private String arrivalTime;
	private String departureTime;
	private double fare;
	private int routeId;
	public TrainMsDto() {
		super();
	}

	public TrainMsDto(int id, String trainName, String arrivalTime, String departureTime, double fare, int routeId) {
		super();
		this.id = id;
		this.trainName = trainName;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.fare = fare;
		this.routeId = routeId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public int getRouteId() {
		return routeId;
	}

	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}

	@Override
	public String toString() {
		return "TrainMsDto [id=" + id + ", trainName=" + trainName + ", arrivalTime=" + arrivalTime + ", departureTime="
				+ departureTime + ", fare=" + fare + ", routeId=" + routeId + "]";
	}
	
	public static Train PrepareEntity(TrainMsDto dto)
	{
		Train train=new Train();
		train.setId(dto.getId());
		train.setArrivalTime(dto.getArrivalTime());
		train.setDepartureTime(dto.getDepartureTime());
		train.setFare(dto.getFare());
		train.setRouteId(dto.getRouteId());
		train.setTrainName(dto.getTrainName());
		return train;
	}
	public static TrainMsDto preparedto(Train train)
	{
		TrainMsDto dto=new TrainMsDto();
		dto.setId(train.getId());
		dto.setArrivalTime(train.getArrivalTime());
		dto.setDepartureTime(train.getDepartureTime());
		dto.setFare(train.getFare());
		dto.setRouteId(train.getRouteId());
		dto.setTrainName(train.getTrainName());
		return dto;
	}

}
