package infyrail.Train.dto;

public class TrainUpdate {
	double fare;

	public TrainUpdate() {
		super();
	}

	public TrainUpdate(double fare) {
		super();
		this.fare = fare;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}
}
