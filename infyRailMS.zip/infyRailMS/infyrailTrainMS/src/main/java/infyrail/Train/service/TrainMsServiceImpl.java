package infyrail.Train.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import infyrail.Train.Repo.TrainMsRepo;
import infyrail.Train.dto.TrainMsDto;
import infyrail.Train.dto.TrainUpdate;
import infyrail.Train.entity.Train;
@Service
public class TrainMsServiceImpl implements TrainMsService {
@Autowired
TrainMsRepo trainmsRepo;
	public int createTrain(TrainMsDto dto) {
		Train train=TrainMsDto.PrepareEntity(dto);
		trainmsRepo.save(train);
		return train.getId();
	}
	@Override
	public String updateFare(int id,TrainUpdate fare) {
		Train train=trainmsRepo.getById(id);
		if(train!=null)
		{
			train.setFare(fare.getFare());
			trainmsRepo.save(train);
			return "successfully updated";
		}
		else
		return "train with"+id+"does not exist";
	}
	public List<TrainMsDto> getTrainByRouteId(int routeId) {
		List<Train> trainl=trainmsRepo.findByRouteId(routeId);
		List<TrainMsDto> Dtol=new ArrayList<>();
		TrainMsDto dto=new TrainMsDto();
		for(Train d:trainl)
		{
			dto=TrainMsDto.preparedto(d);
			Dtol.add(dto);
		}
		return Dtol;
	}
	@Override
	public String deleteTrain(int rid, int id) {
		Train train=trainmsRepo.getById(id);
		if(train!=null)
		{
		trainmsRepo.delete(train);
		return "deleted succesfully";
		}
		else
			return "train with id "+id+"does not exist";

}
	@Override
	public void updateTrainDetailsByRouteId(int id, List<TrainMsDto> Traindetails) {
		for(TrainMsDto dto:Traindetails)
		{
			if(dto.getArrivalTime()!=null)
				dto.setArrivalTime(dto.getArrivalTime());
			if(dto.getDepartureTime()!=null)
				dto.setDepartureTime(dto.getDepartureTime());
			dto.setRouteId(id);
			Train train=TrainMsDto.PrepareEntity(dto);
			trainmsRepo.save(train);
		}
		//return "updated succesfully";
	}
}
